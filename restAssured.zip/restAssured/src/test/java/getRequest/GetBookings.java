package getRequest;

import org.testng.Assert;
import org.testng.annotations.Test;

import static io.restassured.RestAssured.*;

public class GetBookings {
	
	@Test
	public void GetBookingsData() {
		String data = get("https://automationintesting.online/booking").asString();
		System.out.println("Data is: " + data);
		Assert.assertTrue(data.contains("\"bookingid\":" + 3));
		Assert.assertTrue(data.contains("\"bookingid\":" + 1));
			
	}

}