package getRequest;

import org.testng.Assert;
import org.testng.annotations.Test;

import static io.restassured.RestAssured.*;

public class GetBooking {
	
	@Test
	public void GetBookingData() {
		String data = get("https://automationintesting.online/booking/3").asString();
		System.out.println("Data is: " + data);
		Assert.assertTrue(data.contains("\"bookingid\":" + 3));
			
	}

}
