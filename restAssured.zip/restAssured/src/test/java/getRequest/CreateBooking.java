package getRequest;

import org.json.simple.JSONObject;
import org.testng.annotations.Test;

import io.restassured.RestAssured;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;
import junit.framework.Assert;

public class CreateBooking {
	
	@Test
	public void CreateNewBooking() {
		
		RequestSpecification request = RestAssured.given();
		
		request.header("Content-Type","application/json");
		
		JSONObject json = new JSONObject();
		json.put("roomid", "2");
		json.put("firstname", "FtName");
		json.put("lastname", "LtName");
		json.put("depositpaid", "true");
		json.put("checkin", "2020-02-22");
		json.put("checkout", "2020-02-23");
		
		request.body(json.toString());
		
		Response res = request.post("https://automationintesting.online/booking/");
		int StatusCode = res.getStatusCode();
		System.out.println("Status Code is: " + StatusCode);
		Assert.assertEquals(StatusCode, 201);
		
	}

}
