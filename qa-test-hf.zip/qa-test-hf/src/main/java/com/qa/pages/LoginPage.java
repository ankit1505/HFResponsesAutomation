package com.qa.pages;

import java.util.Date;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.qa.base.TestBase;

public class LoginPage extends TestBase {	
		
	@FindBy(xpath = "//a[@class='login']")
	WebElement signInLogo;
	
	@FindBy(id = "email")
	WebElement regEmail;
	
	@FindBy(id = "passwd")
	WebElement password;
	
	@FindBy(id = "SubmitLogin")
	WebElement signInBtn;
	
	@FindBy(id = "email_create")
	WebElement newEmail;
	
	@FindBy(id = "SubmitCreate")
	WebElement CreateAnAccountBtn;
	
	@FindBy(id = "id_gender2")
	WebElement TitleMrs;
	
	@FindBy(id = "customer_firstname")
	WebElement ftName;
	
	@FindBy(id = "customer_lastname")
	WebElement ltName;
	
	@FindBy(id = "passwd")
	WebElement newPassword;
	
	@FindBy(id = "days")
	WebElement days;
	
	@FindBy(id = "months")
	WebElement months;
	
	@FindBy(id = "years")
	WebElement years;
	
	@FindBy(id = "company")
	WebElement Company;
	
	@FindBy(id = "address1")
	WebElement address1;
	
	@FindBy(id = "address2")
	WebElement address2;
	
	@FindBy(id = "city")
	WebElement city;
	
	@FindBy(id = "id_state")
	WebElement state;
	
	@FindBy(id = "postcode")
	WebElement postcode;
	
	@FindBy(id = "other")
	WebElement other;
	
	@FindBy(id = "phone")
	WebElement HomePhone;
	
	@FindBy(id = "phone_mobile")
	WebElement MobilePhone;
	
	@FindBy(id = "alias")
	WebElement aliasAddress;
	
	@FindBy(id = "submitAccount")
	WebElement RegisterBtn;
	
	//Initializing the Page Objects:
	public LoginPage() {
		PageFactory.initElements(driver, this);
	}
	
	//Actions:
	public String ValidateLoginPageTitle() {
		return driver.getTitle();
	}
	
	public HomePage Login(String un, String pwd) {
		signInLogo.click();
		regEmail.sendKeys(un);
		password.sendKeys(pwd);
		signInBtn.click();
		return new HomePage();
				
	}
	
	public HomePage addNewUser(String firstName, String lastName) {
		signInLogo.click();
		String timestamp = String.valueOf(new Date().getTime());
        String email = "hf_challenge_" + timestamp + "@hf" + timestamp.substring(7) + ".com";
        newEmail.sendKeys(email);
        CreateAnAccountBtn.click();
        TitleMrs.click();
        ftName.sendKeys(firstName);
        ltName.sendKeys(lastName);
        newPassword.sendKeys("Qwerty");
        
        Select selectDay = new Select(days);
        selectDay.deselectByValue("1");
        
        Select selectMonth = new Select(months);
        selectMonth.deselectByValue("1");
        
        Select selectYear = new Select(years);
        selectYear.selectByValue("2000");
        Company.sendKeys("Company");
        address1.sendKeys("Qwerty, 123");
        address2.sendKeys("zxcvb");
        city.sendKeys("Qwerty");
        
        Select selectState = new Select(state);
        selectState.deselectByValue("Colorado");
        
        postcode.sendKeys("12345");
        other.sendKeys("Qwerty");
        HomePhone.sendKeys("12345123123");
        MobilePhone.sendKeys("12345123123");
        aliasAddress.sendKeys("hf");
        RegisterBtn.click();
        
        return new HomePage();
		
	}

}
