package com.qa.pages;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.qa.base.TestBase;

public class HomePage extends TestBase {
	
	@FindBy(xpath = "//a[@class='logout']")
	WebElement SignOut;
	
	@FindBy(xpath = "//span[contains(text(),'Joe Black')]")
	WebElement FullName;
	
	@FindBy(linkText = "Women")
	WebElement WOMENTab;
	
	@FindBy(xpath = "//a[contains(text(),'Faded Short Sleeve T-shirts')]")
	WebElement FadedShortSleeveTshirt;
	
	@FindBy(xpath = "//span[contains(text(),'Add to cart')]")
	WebElement AddToCartBtn;
	
	@FindBy(xpath = "//span[contains(text(),'Proceed to checkout')]")
	WebElement CheckOutBtn;
	
	@FindBy(xpath = "//a[@class='button btn btn-default standard-checkout button-medium']//span[contains(text(),'Proceed to checkout')]")
	WebElement CheckOutBtn1;
	
	@FindBy(xpath = "//button[@name='processAddress']//span[contains(text(),'Proceed to checkout')]")
	WebElement CheckOutBtn2;
	
	@FindBy(id = "uniform-cgv")
	WebElement TermNconditionCheckBox;
	
	@FindBy(xpath = "//button[@name='processCarrier']//span[contains(text(),'Proceed to checkout')]")
	WebElement CheckOutBtn3;
	
	@FindBy(className = "bankwire")
	WebElement PayByBankWire;
	
	@FindBy(xpath = "//span[contains(text(),'I confirm my order')]")
	WebElement ConfirmOrderBtn;
	
	@FindBy(xpath = "//h1[@class='page-heading']")
	WebElement OrderConfirmationLogo;
	
	@FindBy(xpath = "//strong[contains(text(),'Your order on My Store is complete.')]")
	WebElement OrderCompletionText;
	
	
	
	//Initializing the Page Objects:
	public HomePage() {
		PageFactory.initElements(driver, this);
	}
	
	//Actions
	
	public String ValidateHomePageTitle() {
		return driver.getTitle();
	}
	
	public LoginPage SignOut() {
		SignOut.click();
		
		return new LoginPage();
	}
	
	public String validateCurrentURL() {
		String HomePageURL = driver.getCurrentUrl();
		return HomePageURL;
	}
	
	public boolean validateSignOut() {
		return SignOut.isDisplayed();
	}
	
	public String validateOrderConfirmationURL() {
		String OrderConfirmPageURL = driver.getCurrentUrl();
		return OrderConfirmPageURL;
	}
	
	public void checkOut() {
		WOMENTab.click();
		FadedShortSleeveTshirt.click();
		AddToCartBtn.click();
		CheckOutBtn.click();
		CheckOutBtn1.click();
		CheckOutBtn2.click();
		TermNconditionCheckBox.click();
		CheckOutBtn3.click();
		PayByBankWire.click();
		ConfirmOrderBtn.click();
		OrderConfirmationLogo.isDisplayed();
		OrderCompletionText.isDisplayed();
		
	}

}
