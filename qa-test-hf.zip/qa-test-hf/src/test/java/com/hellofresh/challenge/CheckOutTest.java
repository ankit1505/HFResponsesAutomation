package com.hellofresh.challenge;

import org.openqa.selenium.By;
import org.testng.Assert;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;
import com.qa.base.TestBase;
import com.qa.pages.HomePage;
import com.qa.pages.LoginPage;
import com.qa.util.WebEventListener;

@Listeners(WebEventListener.class)
public class CheckOutTest extends TestBase {
	
	LoginPage loginPage;
	HomePage homePage;
	
	public CheckOutTest() {
		super();
	}
	
	@BeforeMethod
	public void setup() {
		initialization();
		loginPage = new LoginPage();
		homePage = loginPage.Login(prop.getProperty("username"), prop.getProperty("password"));
	}
	
	@Test
	public void validateCheckOutItemTest() {
		homePage.checkOut();
		
		Assert.assertTrue(homePage.validateOrderConfirmationURL().contains("controller=order-confirmation"));
		//In similar way other validation can be done
		Assert.assertTrue(driver.findElement(By.xpath("//li[@class='step_done step_done_last four']")).isDisplayed());
		Assert.assertTrue(driver.findElement(By.xpath("//li[@id='step_end' and @class='step_current last']")).isDisplayed());
	}
	
	@AfterMethod
	public void TearDown() {
		driver.quit();
	}

}
