package com.hellofresh.challenge;

import org.openqa.selenium.By;
import org.testng.Assert;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;

import com.qa.base.TestBase;
import com.qa.pages.HomePage;
import com.qa.pages.LoginPage;
import com.qa.util.TestUtil;
import com.qa.util.WebEventListener;

@Listeners(WebEventListener.class)
public class SignInTest extends TestBase {
	

	LoginPage loginPage;
	HomePage homePage;
	String sheetName = "contacts";
	
	public SignInTest() {
		super();
	}
	
	@BeforeMethod
	public void setUp() {
		initialization();
		loginPage = new LoginPage();
	}
	
	@DataProvider
	public Object[][] getTestData() {
		Object data[][] = TestUtil.TestData(sheetName);
		return data;
	}
	
	@Test(dataProvider = "getTestData")
	public void validateSignInTest(String First_Name, String Last_Name) {
		loginPage.addNewUser(First_Name, Last_Name);
		String homePageTitle = homePage.ValidateHomePageTitle();
		Assert.assertEquals(homePageTitle, "My account - My Store");
		Assert.assertEquals(driver.findElement(By.className("account")).getText(), First_Name + " " + Last_Name);
		Assert.assertTrue(driver.findElement(By.className("info-account")).getText().contains("Welcome to your account."));
		Assert.assertTrue(homePage.validateCurrentURL().contains("controller=my-account"));
		Assert.assertTrue(homePage.validateSignOut());
	}
	

	@AfterMethod
	public void TearDown() {
		driver.quit();
	}

}
