package com.hellofresh.challenge;

import org.openqa.selenium.By;
import org.testng.Assert;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;
import com.qa.base.TestBase;
import com.qa.pages.HomePage;
import com.qa.pages.LoginPage;
import com.qa.util.WebEventListener;

@Listeners(WebEventListener.class)
public class LoginTest extends TestBase {
	
	LoginPage loginPage;
	HomePage homePage;
	
	public LoginTest() {
		super();
	}
	
	@BeforeMethod
	public void setUp() {
		initialization();
		loginPage = new LoginPage();
	}
	
	@Test
	public void validateLoginTest() {
		homePage = loginPage.Login(prop.getProperty("username"), prop.getProperty("password"));
		String homePageTitle = homePage.ValidateHomePageTitle();
		Assert.assertEquals(homePageTitle, "My account - My Store");
		Assert.assertTrue(driver.findElement(By.className("info-account")).getText().contains("Welcome to your account."));
		Assert.assertTrue(driver.findElement(By.className("logout")).isDisplayed());
		Assert.assertTrue(driver.getCurrentUrl().contains("controller=my-account"));
		Assert.assertTrue(driver.findElement(By.xpath("//a[@class='logout']")).isDisplayed());
		
	}
	
	@AfterMethod
	public void TearDown() {
		driver.quit();
	}
	
	
}
